/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assemblyline;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Faaiz
 */
public class AssemblyLineTest {
    
    public AssemblyLineTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of fastestwayIT method, of class AssemblyLine.
     */
    @Test
    public void testFastestwayIT() {
        System.out.println("fastestwayIT");
        int n = 0;
        int e1 = 0;
        int e2 = 0;
        int e3 = 0;
        int x1 = 0;
        int x2 = 0;
        int x3 = 0;
        int[][] a = null;
        int[][] t = null;
        AssemblyLine instance = new AssemblyLine();
        int expResult = 0;
        int result = instance.fastestwayIT(n, e1, e2, e3, x1, x2, x3, a, t);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
